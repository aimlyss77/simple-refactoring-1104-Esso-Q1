package p1.extract_superclass.org;

public class Employee {
   private int id;
   private int annualCost;
   private String name;

   int getAnnualCost() {
      return this.annualCost;
   }

 String getName() {
      return this.name;
   }

   int getId() {
      return this.id;
   }
}
